const _0x552ac5 = _0x3848;
(function (_0x1e7819, _0x3cc9b9) {
    const _0x2ac6f3 = _0x3848;
    const _0x289b09 = _0x1e7819();
    while (!![]) {
        try {
            const _0x5d4346 = -parseInt(_0x2ac6f3(0x1e8)) / 0x1 + parseInt(_0x2ac6f3(0x202)) / 0x2 * (-parseInt(_0x2ac6f3(0x1fc)) / 0x3) + -parseInt(_0x2ac6f3(0x1fb)) / 0x4 * (-parseInt(_0x2ac6f3(0x1ff)) / 0x5) + -parseInt(_0x2ac6f3(0x1f7)) / 0x6 * (parseInt(_0x2ac6f3(0x1f0)) / 0x7) + -parseInt(_0x2ac6f3(0x206)) / 0x8 * (-parseInt(_0x2ac6f3(0x1fd)) / 0x9) + parseInt(_0x2ac6f3(0x1e9)) / 0xa + parseInt(_0x2ac6f3(0x220)) / 0xb;
            if (_0x5d4346 === _0x3cc9b9) {
                break;
            } else {
                _0x289b09['push'](_0x289b09['shift']());
            }
        } catch (_0x4099d9) {
            _0x289b09['push'](_0x289b09['shift']());
        }
    }
}(_0x225c, 0x8a04a));
const _0x361cdc = (function () {
    let _0x1abb4b = !![];
    return function (_0x18d432, _0xf72efd) {
        const _0x133e1b = _0x1abb4b ? function () {
            if (_0xf72efd) {
                const _0x226c93 = _0xf72efd['apply'](_0x18d432, arguments);
                _0xf72efd = null;
                return _0x226c93;
            }
        } : function () {
        };
        _0x1abb4b = ![];
        return _0x133e1b;
    };
}());
function _0x3848(_0x1203b1, _0xa8dac1) {
    const _0x179474 = _0x225c();
    _0x3848 = function (_0x487f78, _0x361cdc) {
        _0x487f78 = _0x487f78 - 0x1dd;
        let _0x225c77 = _0x179474[_0x487f78];
        return _0x225c77;
    };
    return _0x3848(_0x1203b1, _0xa8dac1);
}
const _0x487f78 = _0x361cdc(this, function () {
    const _0x47789f = _0x3848;
    const _0x49102c = typeof window !== _0x47789f(0x1f9) ? window : typeof process === 'object' && typeof require === 'function' && typeof global === _0x47789f(0x201) ? global : this;
    const _0x1b0596 = _0x49102c[_0x47789f(0x216)] = _0x49102c[_0x47789f(0x216)] || {};
    const _0x4eec7b = [
        _0x47789f(0x1e0),
        _0x47789f(0x20e),
        _0x47789f(0x203),
        _0x47789f(0x1f8),
        'exception',
        _0x47789f(0x1ee),
        _0x47789f(0x1f2)
    ];
    for (let _0x1282a2 = 0x0; _0x1282a2 < _0x4eec7b['length']; _0x1282a2++) {
        const _0x42524e = _0x361cdc[_0x47789f(0x1e2) + 'r']['prototype'][_0x47789f(0x20d)](_0x361cdc);
        const _0x8d4448 = _0x4eec7b[_0x1282a2];
        const _0x40553b = _0x1b0596[_0x8d4448] || _0x42524e;
        _0x42524e[_0x47789f(0x212)] = _0x361cdc[_0x47789f(0x20d)](_0x361cdc);
        _0x42524e['toString'] = _0x40553b[_0x47789f(0x21f)][_0x47789f(0x20d)](_0x40553b);
        _0x1b0596[_0x8d4448] = _0x42524e;
    }
});
_0x487f78();
function _0x225c() {
    const _0x393126 = [
        'Friday',
        'span>',
        'key',
        'April',
        '/data/2.5/',
        'getMonth',
        'toString',
        '2487122WNaORN',
        '°c\x20/\x20',
        'ric&APPID=',
        '.current\x20.',
        '.search-bo',
        'then',
        'temp_min',
        'innerText',
        'stener',
        'May',
        'Sunday',
        'log',
        'temp_max',
        'constructo',
        'June',
        'August',
        'getDate',
        'round',
        'bbb202209b',
        '698797CNILZt',
        '10477940JBVAIm',
        'Thursday',
        'January',
        '.location\x20',
        'sys',
        'table',
        'Wednesday',
        '45283AgdtPU',
        'July',
        'trace',
        'country',
        'getDay',
        'innerHTML',
        '.city',
        '132FFkMnq',
        'error',
        'undefined',
        'main',
        '12OEbeHn',
        '30GsnMfD',
        '11007rgvTHf',
        'hermap.org',
        '335470emizHu',
        'getFullYea',
        'object',
        '26712zSuuIE',
        'info',
        'weather',
        'September',
        '424jGiLee',
        'tor',
        'keyCode',
        '&units=met',
        'bf0261babf',
        'temp',
        'keypress',
        'bind',
        'warn',
        '<span>°c</',
        'October',
        'fcc8de7015',
        '__proto__',
        'Saturday',
        'name',
        'querySelec',
        'console',
        'March',
        '.date'
    ];
    _0x225c = function () {
        return _0x393126;
    };
    return _0x225c();
}
const api = {
    'key': _0x552ac5(0x211) + _0x552ac5(0x1e7) + _0x552ac5(0x20a) + '4c',
    'base': 'https://ap' + 'i.openweat' + _0x552ac5(0x1fe) + _0x552ac5(0x21d)
};
const searchbox = document[_0x552ac5(0x215) + 'tor'](_0x552ac5(0x224) + 'x');
searchbox['addEventLi' + _0x552ac5(0x1dd)](_0x552ac5(0x20c), setQuery);
function setQuery(_0x311174) {
    const _0x40fdc0 = _0x552ac5;
    if (_0x311174[_0x40fdc0(0x208)] == 0xd) {
        getResults(searchbox['value']);
    }
}
function getResults(_0x26d437) {
    const _0x4534ee = _0x552ac5;
    fetch(api['base'] + 'weather?q=' + _0x26d437 + (_0x4534ee(0x209) + _0x4534ee(0x222)) + api[_0x4534ee(0x21b)])['then'](_0x55922d => {
        return _0x55922d['json']();
    })[_0x4534ee(0x225)](displayResults);
}
function displayResults(_0x47cc8f) {
    const _0x1e3133 = _0x552ac5;
    let _0x55a757 = document[_0x1e3133(0x215) + _0x1e3133(0x207)]('.location\x20' + _0x1e3133(0x1f6));
    _0x55a757[_0x1e3133(0x227)] = _0x47cc8f[_0x1e3133(0x214)] + ',\x20' + _0x47cc8f[_0x1e3133(0x1ed)][_0x1e3133(0x1f3)];
    let _0x1b1e93 = new Date();
    let _0x2858ef = document[_0x1e3133(0x215) + _0x1e3133(0x207)](_0x1e3133(0x1ec) + _0x1e3133(0x218));
    _0x2858ef['innerText'] = dateBuilder(_0x1b1e93);
    let _0x2682a8 = document['querySelec' + 'tor'](_0x1e3133(0x223) + _0x1e3133(0x20b));
    _0x2682a8[_0x1e3133(0x1f5)] = Math[_0x1e3133(0x1e6)](_0x47cc8f['main'][_0x1e3133(0x20b)]) + (_0x1e3133(0x20f) + _0x1e3133(0x21a));
    let _0x4b45df = document[_0x1e3133(0x215) + _0x1e3133(0x207)](_0x1e3133(0x223) + _0x1e3133(0x204));
    _0x4b45df['innerText'] = _0x47cc8f[_0x1e3133(0x204)][0x0][_0x1e3133(0x1fa)];
    let _0x5d50b7 = document['querySelec' + _0x1e3133(0x207)]('.hi-low');
    _0x5d50b7[_0x1e3133(0x227)] = Math[_0x1e3133(0x1e6)](_0x47cc8f['main'][_0x1e3133(0x226)]) + _0x1e3133(0x221) + Math[_0x1e3133(0x1e6)](_0x47cc8f[_0x1e3133(0x1fa)][_0x1e3133(0x1e1)]) + '°c';
}
function dateBuilder(_0xb6efbe) {
    const _0x545ca9 = _0x552ac5;
    let _0x302abf = [
        _0x545ca9(0x1eb),
        'February',
        _0x545ca9(0x217),
        _0x545ca9(0x21c),
        _0x545ca9(0x1de),
        _0x545ca9(0x1e3),
        _0x545ca9(0x1f1),
        _0x545ca9(0x1e4),
        _0x545ca9(0x205),
        _0x545ca9(0x210),
        'November',
        'December'
    ];
    let _0xa100ad = [
        _0x545ca9(0x1df),
        'Monday',
        'Tuesday',
        _0x545ca9(0x1ef),
        _0x545ca9(0x1ea),
        _0x545ca9(0x219),
        _0x545ca9(0x213)
    ];
    let _0x714539 = _0xa100ad[_0xb6efbe[_0x545ca9(0x1f4)]()];
    let _0x19e833 = _0xb6efbe[_0x545ca9(0x1e5)]();
    let _0x160932 = _0x302abf[_0xb6efbe[_0x545ca9(0x21e)]()];
    let _0x16effc = _0xb6efbe[_0x545ca9(0x200) + 'r']();
    return _0x714539 + '\x20' + _0x19e833 + '\x20' + _0x160932 + '\x20' + _0x16effc;
}